package com.mvc.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.mvc.repository.Login;
import com.mvc.repository.LoginRepository;

@Service
@Transactional
public class LoginService {
	@Autowired 
	private LoginRepository repo;

	public String authenticate(Login login)
	{
		String toRet = "Failed";		
		Optional<Login>optional = repo.findById(login.getUserName());
		if(optional.isPresent()) {
			Login l = optional.get();
			if(login.getPassword().equals(l.getPassword()))
				toRet = "Success";			
		}
		
		return toRet;
	}

	public void save(Login login) {
		repo.save(login);
	}
}
