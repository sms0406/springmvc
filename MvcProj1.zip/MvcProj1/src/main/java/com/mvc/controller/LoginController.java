package com.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mvc.repository.Login;
import com.mvc.service.LoginService;

@Controller
public class LoginController {
	@Autowired
	private LoginService service;
	
	@RequestMapping("/")
	public ModelAndView home() {
	    
	    ModelAndView mav = new ModelAndView("index");
	   
	    return mav;
	}
	@RequestMapping(value = "/login")
	public ModelAndView authenticateCustomer(@RequestParam String name,
			@RequestParam String password) throws Exception {
		Login login = new Login();
		login.setUserName(name);
		login.setPassword(password);
		System.out.println("inside authenticate");
		String flag = service.authenticate(login);
		System.out.println("flag "+flag);
		if (flag.equals("Success")) {
			ModelAndView modelAndView = new ModelAndView("welcome");
			modelAndView.addObject("username", name);
			return modelAndView;
		} else
			return new ModelAndView("error");
	}
}
